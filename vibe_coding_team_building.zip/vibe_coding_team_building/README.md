# Hold'em Co-Pilot

A self-contained Texas Hold'em assistant. You type in everything happening at
the table (your hole cards, the community cards, pot, bet to call, etc.) and the
app tells you the next action to take.

The decision is made by a small piece of **JavaScript that you can edit** — or
that you can have an AI write for you. That makes the "brain" of the computer
fully swappable.

## Running it

No build step, no server, no internet. Just open `index.html` in any modern
browser (double-click it, or drag it into a browser window).

## How to use

1. **Players & Blinds** — each player is a card showing their chip count.
   - **Player 1 is always you.**
   - **Add player** / the **×** on a card add or remove players (anywhere).
   - Set the blind amounts, then choose who has the **big blind** (use the
     dropdown, or click any player's position tag). Every other role — SB, BTN,
     UTG, etc. — follows automatically, because Hold'em position is
     deterministic once you know the blinds.
   - Edit any chip count directly.
2. **Cards** — click a card slot on the felt (your two hole cards, then the
   board) and pick the matching card from the grid. Used cards grey out.
3. **Action Sequence** — the blinds post automatically, then the app shows
   whose turn it is (player left of the BB acts first) and offers only the legal
   moves. Bet/raise sizing is flexible: type any amount or use the quick chips
   (½ pot, pot, all-in). The pot, current bet, amount to call, who's left, and
   the street are all **derived** from the sequence — you never type them.
4. Click **Estimate Equity** for win / tie / lose chances, or
   **Compute Next Action** to get a recommended move.
5. **Next game** rotates the blinds one seat and carries every stack forward
   automatically (losers' chips out, the pot to the winner you pick).

## The AI strategy API

The bottom panel holds the code the computer runs. Edit it (or paste AI code)
and click **Apply Strategy**. Your code must define:

```js
function decide(state, helpers) {
  // ...
  return { action, amount, confidence, reasoning };
}
```

### `state` — what's happening at the table

All of these are derived from the recorded action sequence:

| field             | type     | meaning                                              |
| ----------------- | -------- | ---------------------------------------------------- |
| `hole`            | string[] | your 2 cards, e.g. `["As","Kd"]`                     |
| `board`           | string[] | 0–5 community cards                                   |
| `players`         | number   | total players seated                                 |
| `activeOpponents` | number   | opponents still in the hand                          |
| `position`        | string   | your position label (`SB`/`BB`/`UTG`/.../`BTN`)      |
| `street`          | string   | `preflop`/`flop`/`turn`/`river`                      |
| `pot`             | number   | current pot size                                     |
| `toCall`          | number   | amount you must put in to call (0 = can check)       |
| `currentBet`      | number   | the bet to match on this street                      |
| `heroStack`       | number   | your remaining stack                                 |
| `heroContributed` | number   | chips you've already put in this hand                |
| `bigBlind`        | number   | big blind size                                       |
| `smallBlind`      | number   | small blind size                                     |
| `toActIsHero`     | boolean  | is it currently your turn?                           |
| `handOver`        | boolean  | is the hand already decided in the sequence?         |
| `history`         | string[] | the full action log, e.g. `["SB posts 0.5", ...]`   |
| `seats`           | object[] | per-seat `{pos, stack, totalContrib, folded, ...}`  |

### `helpers` — tools you can call

| helper                                        | returns                                            |
| --------------------------------------------- | -------------------------------------------------- |
| `equity(hole, board, opponents[, iters])`     | `{ win, tie, lose, equity }` (equity is 0–1)       |
| `potOdds(toCall, pot)`                         | call price as a fraction 0–1                       |
| `round(n)`                                     | rounds to 2 decimals                               |
| `clamp(n, lo, hi)`                             | clamps a number                                    |

### Return value

```js
{
  action: "fold" | "check" | "call" | "bet" | "raise",
  amount: 12.5,        // chips for bet/raise/call (0 for fold/check)
  confidence: 0.82,    // 0–1, optional
  reasoning: "why"     // shown to the user, optional
}
```

## Files

Each file does one focused thing:

- `index.html` — layout and script includes
- `css/styles.css` — all styling
- `js/cards.js` — card model + deck helpers
- `js/handEval.js` — best-5-of-7 hand evaluator
- `js/equity.js` — Monte Carlo equity simulation
- `js/positions.js` — position labels + betting order per player count
- `js/table.js` — the betting engine (replays the sequence into a state)
- `js/tableModel.js` — the live table state (players, blinds, chips, sequence)
- `js/strategy.js` — the default editable strategy code
- `js/engine.js` — compiles + runs the strategy safely
- `js/cards-ui.js` — the card picker
- `js/results-ui.js` — the recommendation / equity panel + code editor
- `js/betting-ui.js` — table setup + the action-sequence recorder
- `js/main.js` — wires it all together

Everything runs locally in the browser; no data ever leaves the page.
