/*
 * tableModel.js
 * The single source of truth for the table: the list of players (seat 0 is
 * always the user), which seat is the big blind, the blind sizes, and the
 * recorded action sequence. Other positions are derived from the big blind.
 *
 * It owns all mutations (add / remove player, set big blind, record actions,
 * start the next game) and can replay the hand via the betting engine.
 * The UI layer only reads from here and calls these mutators.
 */
(function (global) {
  "use strict";

  var MAX_PLAYERS = 10;
  var MIN_PLAYERS = 2;

  var players = [];   // [{ stack }], index 0 = hero (the user)
  var bbIndex = 2;    // physical seat that currently posts the big blind
  var sb = 1;
  var bb = 2;
  var newStack = 200; // default stack given to newly added players
  var actions = [];   // recorded action sequence for the current hand

  function init() {
    players = [];
    for (var i = 0; i < 6; i++) players.push({ stack: 200 });
    bbIndex = 2;
    sb = 1; bb = 2; newStack = 200;
    actions = [];
  }

  // ---- replay ----
  function compute() {
    var n = players.length;
    var sbIndex = (bbIndex - 1 + n) % n;
    return global.Poker.table.computeState(
      { n: n, sb: sb, bb: bb, stacks: players.map(function (p) { return p.stack; }), heroIndex: 0, sbIndex: sbIndex },
      actions
    );
  }

  // ---- setup mutators (these invalidate the current hand) ----
  function setSB(v) { sb = numOr(v, sb); actions = []; }
  function setBB(v) { bb = numOr(v, bb); actions = []; }
  function setNewStack(v) { newStack = numOr(v, newStack); }
  function setStack(i, v) { if (players[i]) { players[i].stack = numOr(v, players[i].stack); actions = []; } }
  function setBBIndex(i) { if (i >= 0 && i < players.length) { bbIndex = i; actions = []; } }

  function addPlayerAfter(i) {
    if (players.length >= MAX_PLAYERS) return;
    var pos = Math.min(players.length, i + 1);
    players.splice(pos, 0, { stack: newStack });
    if (bbIndex >= pos) bbIndex++;
    actions = [];
  }

  function removePlayer(i) {
    if (i === 0) return;                 // never remove the user
    if (players.length <= MIN_PLAYERS) return;
    players.splice(i, 1);
    if (bbIndex > i) bbIndex--;
    if (bbIndex >= players.length) bbIndex = players.length - 1;
    actions = [];
  }

  // ---- action sequence ----
  function pushAction(type, amount) { actions.push({ type: type, amount: amount }); }
  function undo() { actions.pop(); }
  function resetActions() { actions = []; }

  // ---- next game: rotate blinds + carry chips forward ----
  function nextGame(winnerIndex) {
    var s = compute();
    var n = players.length;
    for (var i = 0; i < n; i++) players[i].stack = s.remaining[i];

    var winner = resolveWinner(s, winnerIndex);
    if (winner != null) players[winner].stack = players[winner].stack + s.pot;

    bbIndex = (bbIndex + 1) % n;
    actions = [];
  }

  function resolveWinner(s, chosen) {
    if (chosen != null && s.activeSeats.indexOf(chosen) >= 0) return chosen;
    if (s.activeSeats.length === 1) return s.activeSeats[0];
    if (s.activeSeats.indexOf(0) >= 0) return 0; // default to the user at showdown
    return s.activeSeats.length ? s.activeSeats[0] : null;
  }

  function defaultWinner(s) { return resolveWinner(s, null); }

  // ---- state for strategy/equity ----
  function getStrategyState() {
    var s = compute();
    return {
      players: players.length,
      activeOpponents: Math.max(1, s.activeOpponents),
      position: s.labels[0],
      street: s.street,
      pot: s.pot,
      toCall: s.heroToCall,
      heroStack: s.heroStack,
      heroContributed: s.heroContributed,
      currentBet: s.currentBet,
      bigBlind: bb,
      smallBlind: sb,
      handOver: s.handOver,
      toActIsHero: s.toAct === 0,
      history: s.log.map(function (e) { return e.text; }),
      seats: s.seats
    };
  }

  // ---- reads ----
  function getPlayers() { return players; }
  function getBBIndex() { return bbIndex; }
  function getSetup() { return { sb: sb, bb: bb, newStack: newStack }; }

  // Chips are integers only.
  function numOr(v, d) { var x = parseInt(v, 10); return isNaN(x) ? d : Math.max(0, x); }

  global.Poker = global.Poker || {};
  global.Poker.model = {
    init: init, compute: compute,
    setSB: setSB, setBB: setBB, setNewStack: setNewStack, setStack: setStack, setBBIndex: setBBIndex,
    addPlayerAfter: addPlayerAfter, removePlayer: removePlayer,
    pushAction: pushAction, undo: undo, resetActions: resetActions,
    nextGame: nextGame, defaultWinner: defaultWinner,
    getStrategyState: getStrategyState,
    getPlayers: getPlayers, getBBIndex: getBBIndex, getSetup: getSetup,
    MAX_PLAYERS: MAX_PLAYERS, MIN_PLAYERS: MIN_PLAYERS
  };
})(window);
